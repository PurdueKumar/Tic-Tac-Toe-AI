#pragma once

#include "game.h"

class player {

public:
	virtual int move(int * , int *) = 0;

};
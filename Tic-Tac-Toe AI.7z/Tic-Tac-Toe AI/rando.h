#pragma once

#include "player.h"

class rando : public player {

public:
	int move(int * , int *);

};
#pragma once

#include"player.h"

class human : public player {

public:

	int move(int * , int *);

};